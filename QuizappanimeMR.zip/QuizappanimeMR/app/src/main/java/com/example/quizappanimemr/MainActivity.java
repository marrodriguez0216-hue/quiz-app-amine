package com.example.quizappanimemr;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button trueButton;
    Button falseButton;

    Button backButton;

    Button nextButton;

    Button hintButton;

    TextView question;

    int questionNumber = 0;

    int score = 0;

    ArrayList<Question> list = new ArrayList<>();


    @SuppressLint("MissingInflatedId")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        question = findViewById(R.id.question);
        trueButton = findViewById(R.id.b_True);
        falseButton = findViewById(R.id.b_False);
        backButton = findViewById(R.id.backButton);
        nextButton = findViewById(R.id.nextButton);
        hintButton = findViewById(R.id.hintButton);


        list.add(new Question("Does Anna from spy x family have mind power", true, "She can know what your thinking about"));
        list.add(new Question("Did fluffy ever find the one piece", false, " Did the series end"));
        list.add(new Question("Did nortti become hakama of the hidden leaf", true, "Became like end of his  life"));
        list.add(new Question("Was levi the captain of his team", true, " He got the main on his team with his postion"));
        list.add(new Question("Ash Ketchum has aged noticeably throughout the pokemon series ", true, "Has always remind the same look"));


        Question currentQuestion = list.get(questionNumber);


        // get the current question and set its text to the TextView named question
        question.setText(list.get(questionNumber).getQuestionText());

        // when we click
        trueButton.setOnClickListener(v -> {
            if (currentQuestion.isAnswerTrue()) {
                score++;
            }
        });

        falseButton.setOnClickListener(v -> {
            if (currentQuestion.isAnswerTrue()) {
                score++;
            }
        });

        public void onHintClicked(View v){
            Question current = list.get(questionNumber);
            intent = new Intent(MainActivity.this, ViewHintActivity.class);
            intent.putExtra("Hint", current.getHint());
            startActivity(intent);

        }

        protected void Questionfile  throws IOException {
            FileOutputStream fOut = openFileOutput("questionText".Context.MODE_PRIVATE);
            String question = "test 1 " + "test 2" + "test 3" + "test 4 "+ "test 5" ;
            fOut.write(question.getBytes());
            fOut.close();

        }



    }
}}


