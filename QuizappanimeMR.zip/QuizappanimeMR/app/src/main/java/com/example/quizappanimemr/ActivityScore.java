package com.example.quizappanimemr;

public class ActivityScore {
    private static int score = 0;

    public int getScore() {
        return score;
    }

    public static void setScore(int score) {
        ActivityScore.score = score;
    }

    public int  resetScore(){
        return 0;
  }
    public static int addScore(){
        score++;
    }



}
