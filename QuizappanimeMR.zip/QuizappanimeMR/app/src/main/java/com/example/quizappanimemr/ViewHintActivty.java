package com.example.quizappanimemr;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

TextView hintText;
public class viewHintActivty extends AppCompatActivity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        hintText = findViewById(R.id.hintText);
        String hint = getIntent().getStringExtra("hint");
        hintText.setText(hint);
    }
}
