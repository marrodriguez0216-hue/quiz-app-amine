package com.example.quizappanimemr;

import android.app.Activity;

public class Correct {
    if(score > 3){

    }

}
