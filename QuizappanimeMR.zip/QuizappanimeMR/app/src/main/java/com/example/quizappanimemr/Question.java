package com.example.quizappanimemr;

public class Question {

    private String questionText;

    private boolean isAnswerTrue;

    private final String hintText;


    public Question(String questionText,boolean isAnswerTrue,String hintText) {
        this.questionText = questionText;
        this.isAnswerTrue = isAnswerTrue;
        this.hintText = hintText;
    }
    public String getQuestionText(){

        return questionText;
    }

    public void setQuestionText(String questionText) {

        this.questionText = questionText;
    }

    public boolean isAnswerTrue() {

        return isAnswerTrue;
    }

    public void setAnswerTrue(boolean answerTrue) {

        isAnswerTrue = answerTrue;
    }
public String getHintText(){
        return hintText;
}

}
